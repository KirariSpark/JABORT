from enum import Enum
from .KSEnums import LogLevels

class StatusBase(Enum):
    """
    状态类基类
    """
    def __init__(self, level: LogLevels, message: str):
        """
        定义一个状态

        :param level: 标注这个状态的等级，使用日志等级枚举
        :param message: 这个状态所对应的自然语言含义，通常来说，这个内容用于展示给用户，所以应该保持简单
        """
        self._message = message
        self._level = level

    @property
    def message(self) -> str:
        return self._message

    @property
    def level(self) -> LogLevels:
        return self._level

    def __str__(self) -> str:
        return f"[{self._level.value} | {self.name}] {self._message}"

class Statuses(StatusBase):
    """
    一些已经定义好的，可以直接使用的状态。  
    通常来说，这里只包含基础的状态和错误，更多状态应使用基类进行自定义。
    """
    # Info
    Success = (LogLevels.Info, "成功")

    # Error
    Unknown = (LogLevels.Error, "未知错误")
    EmptyInput = (LogLevels.Error, "输入内容为空")
    InvalidInput = (LogLevels.Error, "无效的输入")
    InvalidParameter = (LogLevels.Error, "无效的参数")
    ParameterMissing = (LogLevels.Error, "缺少必要的参数")
    TypeMismatch = (LogLevels.Error, "输入的数据类型不符合要求")
    OutOfRange = (LogLevels.Error, "数值超出允许范围")
    MissingKey = (LogLevels.Error, "输入缺失必要的键")
    PathNotExist = (LogLevels.Error, "要求的路径不存在")
    FileNotFound = (LogLevels.Error, "找不到文件")
    FileAlreadyExists = (LogLevels.Error, "文件已存在")
    FileReadError = (LogLevels.Error, "读取文件失败")
    FileWriteError = (LogLevels.Error, "写入文件失败")
    DirectoryCreateFailed = (LogLevels.Error, "创建目录失败")
    PermissionDenied = (LogLevels.Error, "权限不足")

    # Warning
    TypeWarning = (LogLevels.Warning, "请求的输入因类型不正确而取消")
    KeyExists = (LogLevels.Warning, "输入的键已经存在，此次输入已经取消")
    