from typing import TypedDict, TypeVar, Optional, Generic, NotRequired
from .KSStatus import Statuses, StatusBase
from .KSEnums import LogLevels
import json
from pathlib import Path

T = TypeVar('T')

class ExtraStatuses(StatusBase):
    CfgFileNotSet = (LogLevels.Warning, "配置文件路径未被设置，此次对文件的读写已取消")

class KSConfigItemDict(TypedDict, Generic[T]):
    name: str
    value: NotRequired[Optional[T]]
    default: T

class KSConfigItem(Generic[T]):
    """
    单个配置项类
    """
    def __init__(self, name:str, default: T, value: Optional[T] = None) -> None:
        """
        创建一个配置项
        
        :param name: 这个配置项的名称，用于标识它；它也是保存配置时这个项目的键名
        :param default: 这个配置的默认值
        :param value: 这个配置的初始值，若不提供则初始值就是默认值
        """
        self._name: str = name
        self._value: Optional[T] = value if value else default
        self._default: T = default

    def to_dict(self) -> KSConfigItemDict[T]:
        """
        将此配置项变成字典，便于存储
        """
        return {
            "name": self._name,
            "value": self._value,
            "default": self._default
        }

    @classmethod
    def from_config_dict(cls, d: KSConfigItemDict[T]) -> tuple[StatusBase, Optional['KSConfigItem[T]']]:
        """
        从字典恢复配置项

        :param d: 要从中恢复数据的字典
        :returns: 元组，第一项为状态信息，第二项为类的实例（如果状态是成功的话）
        """
        if "name" in d and "default" in d:
            v = d.get("value", d["default"])
            if type(d["name"]) == str and type(v) == type(d["default"]):
                return Statuses.Success, cls(d["name"], d["default"],v)
            return Statuses.TypeMismatch, None
        return Statuses.MissingKey, None

    def set_value(self, value: T) -> StatusBase:
        """
        设置这个配置项的值
        """
        if type(value) == type(self._default):
            self._value = value
            return Statuses.Success
        return Statuses.TypeWarning

    def reset(self) -> None:
        self._value = self._default

    def is_me(self, name:str) -> bool:
        return name == self._name

    @property
    def value(self) -> T:
        return self._value if self._value else self._default

    @property
    def name(self) -> str:
        return self._name

    def __str__(self) -> str:
        return f"[Config: {self._name}] {self._value} (default: {self._default})"

class KSConfigManager(Generic[T]):
    def __init__(self) -> None:
        self._items: dict[str, KSConfigItem] = {}
        self._file: Path | None = None

    def set_file(self, path: str) -> None:
        """
        为当前配置管理器实例设置一个文件路径，此后的文件操作将会使用这个路径代表的文件
        """
        f = Path(path)
        f.parent.mkdir(exist_ok=True, parents=True)
        f.touch()
        self._file = f

    def save(self) -> StatusBase:
        """ 
        向此前使用 set_file 设置的文件里写入当前配置
        """
        if self._file is None:
            return ExtraStatuses.CfgFileNotSet
        
        try:
            data_list = [item.to_dict() for item in self._items.values()]
            with open(self._file, 'w', encoding='utf-8') as f:
                json.dump(data_list, f, indent=4, ensure_ascii=False)
            return Statuses.Success
        except Exception:
            return Statuses.FileWriteError

    def load(self) -> StatusBase:
        """ 
        从此前使用 set_file 设置的文件里读取配置
        它会将你已有的配置项和来自文件的配置项合并，优先使用来自文件的配置项
        """
        if self._file is None:
            return ExtraStatuses.CfgFileNotSet
        
        if not self._file.exists():
            return Statuses.FileNotFound

        try:
            # 处理空文件的情况，避免 json.load 报错
            with open(self._file, 'r', encoding='utf-8') as f:
                content = f.read()
                if not content.strip():
                    return Statuses.Success
            
            # 读取并解析 JSON
            with open(self._file, 'r', encoding='utf-8') as f:
                data_list = json.load(f)
            
            if isinstance(data_list, list):
                for item_dict in data_list:
                    status, item = KSConfigItem.from_config_dict(item_dict)
                    if status == Statuses.Success and item is not None:
                        # 优先使用来自文件的配置项，直接更新或添加
                        self.set_item(item)
            
            return Statuses.Success
        except (json.JSONDecodeError, OSError):
            return Statuses.FileReadError
        except Exception:
            return Statuses.Unknown

    def register(self, item: KSConfigItem) -> StatusBase:
        """
        注册一个配置项目

        :param item: 要注册的配置项
        """
        if item.name in self._items.keys():
            return Statuses.KeyExists
        self._items[item.name] = item
        return Statuses.Success

    def register_all(self, items: list[KSConfigItem]) -> StatusBase:
        """
        批量注册一堆配置项目

        :param items: 要注册的配置项的列表
        """
        for i in items:
            stat = self.register(i)
            if stat != Statuses.Success:
                return stat
        return Statuses.Success

    def get_item(self, name: str) -> tuple[StatusBase, Optional['KSConfigItem[T]']]:
        """
        获取配置项对象

        :param name: 配置项名称
        :return: 元组，第一项为状态，第二项为配置项对象（如果状态为成功）
        """
        if name in self._items:
            return Statuses.Success, self._items[name]
        return Statuses.MissingKey, None

    def get_value(self, name: str) -> tuple[StatusBase, Optional[T]]:
        """
        获取配置项的值

        :param name: 配置项名称
        :return: 元组，第一项为状态，第二项为配置项的值（如果状态为成功）
        """
        status, item = self.get_item(name)
        if status == Statuses.Success and item is not None:
            return Statuses.Success, item.value
        return status, None

    def set_item(self, item: KSConfigItem) -> StatusBase:
        """
        设置（更新或添加）配置项对象

        :param item: 新的配置项对象
        :return: 状态
        """
        self._items[item.name] = item
        return Statuses.Success

    def set_value(self, name: str, value: T) -> StatusBase:
        """
        设置指定配置项的值
        :param name: 配置项名称
        :param value: 新的值
        :return: 状态
        """
        status, item = self.get_item(name)
        if status == Statuses.Success and item is not None:
            return item.set_value(value)
        return status

    def clear(self) -> None:
        """
        清除所有已注册的配置项
        """
        self._items = {}

    def d_all_items(self) -> dict[str, KSConfigItem]:
        """
        获取当前所有已注册的配置项
        """
        return self._items