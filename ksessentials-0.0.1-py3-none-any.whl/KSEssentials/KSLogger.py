from loguru import logger
from .KSEnums import LogLevels
from pathlib import Path
from datetime import datetime
import zipfile, os

def init_logger(level: LogLevels = LogLevels.Info, max_archives: int = 50):
    """
    初始化一个 Loguru Logger，自带文件写入，写入到 ./logs/latest.log。  
    同时会将之前的日志进行归档，归档文件名为 <被归档的日志最后修改的日期和时间>.zip。

    :param level: 日志等级
    :param max_archives: 最多保留多少个归档文件，超过此数量的早期归档将会被删除
    """
    # 参数错了就回到默认值
    max_archives = 50 if max_archives <= 0 else int(max_archives)

    log_dir = Path("logs")
    log_file = log_dir / "latest.log"
    log_dir.mkdir(parents=True, exist_ok=True)

    # 归档日志
    if log_file.exists() and os.path.getsize(log_file) > 0:
        try:
            mod_timestamp = os.path.getmtime(log_file)
            dt = datetime.fromtimestamp(mod_timestamp)
            timestamp_str = dt.strftime('%Y-%m-%d_%H-%M-%S')
            archive_path = log_dir / f"{timestamp_str}.zip"

            with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED) as zf:
                zf.write(log_file, arcname=log_file.name)
            
            os.remove(log_file)
        except Exception as e:
            print(f"Failed to archive log file: {e}")

    # 清理归档
    try:
        archives = sorted(log_dir.glob("*.zip"), key=lambda f: f.stat().st_mtime)
        while len(archives) > max_archives:
            oldest_archive = archives.pop(0)
            oldest_archive.unlink()
    except Exception as e:
        print(f"Failed to clean old archives: {e}")

    logger.add("./logs/latest.log", level=level.value) # type: ignore
    pass